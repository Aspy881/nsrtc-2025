import ThemesGrid from "../../components/organisms/ThemesGrid"

export default function ThemesPage() {
  return <ThemesGrid preview={false} />
}
