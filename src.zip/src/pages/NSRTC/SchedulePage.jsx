import ScheduleTimeline from "../../components/organisms/ScheduleTimeline"

export default function SchedulePage() {
  return <ScheduleTimeline preview={false} />
}
